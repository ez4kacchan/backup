cp drawframe ~/prog/bin && chmod u+x ~/prog/bin/drawframe
