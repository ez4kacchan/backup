// Library de tuong tac voi X Serverxfix
#include <X11/Xlib.h>
#include <X11/extensions/shape.h>
#include <X11/extensions/Xfixes.h>

#include <string.h>
#include <stdio.h>
#include <iostream>
// Library de tuong tac voi IO input

#include "main.h"

int main(int argc, char **argv){
  Display *display;

  display = XOpenDisplay(NULL);
  int screen = DefaultScreen(display);
  int dodai_chunhat, dorong_chunhat;
  
  Window WindowGoc = XRootWindow(display, screen);
  // WindowGoc dua vao thong tin cua display va screen
  Window cuaso_chinh;

  // Doc thong tin dau vao 
  for (int i=1; i<argc; i++){
    if (!(strcmp(argv[i], "-w"))){
      if (i+1<argc){
        dodai_chunhat = std::stoi(argv[i+1]);
      }
    }
    if (!(strcmp(argv[i], "-h"))){
      if (i+1<argc){
        dorong_chunhat = std::stoi(argv[i+1]);
      }
    }
  }

  char buf;
  
  cuaso_chinh = khoitao_window(display, screen, WindowGoc, 5, 5, 1910, 1070, 5);

  // Ve hinh chu nhat
  // (780,400) la goc thu nhat, (1620, 550) la goc thu hai, (1370, 320) la goc thu ba 
  ve_hinhchunhat(display, screen, cuaso_chinh, 780, 400, 20, 20);
  ve_hinhchunhat(display, screen, cuaso_chinh, 1620, 550, 20, 20);
  ve_hinhchunhat(display, screen, cuaso_chinh, 960, 400, 20, 20);
  ve_hinhchunhat(display, screen, cuaso_chinh, 1370, 320, 20, 20);

  if (cuaso_chinh == 0) {
    printf("Khoi tao khong thanh cong");
    return 1;
  }

  printf("An Enter de thoat");
  scanf("%c", &buf);
}


void doc_thongtin(int argc, char **argv){
  printf("argc: %d \n", argc);
  for (int i=1; i<argc; i++){
    if (!(strcmp(argv[i], "-c"))){
      if (i+1<argc){
        printf("arg cho color: %s \n", argv[i+1]);
      }
    }
    if (!(strcmp(argv[i], "-r"))){
      if (i+1<argc){
        printf("arg cho color: %s \n", argv[i+1]);
      }
    }
  }
}


Window khoitao_window(Display *dp, int screen, Window WindowGoc, int x_phanbu, int y_phanbu, int do_dai, int  do_rong, int dolon_vien){
  Window cua_so;
  XSetWindowAttributes thuoc_tinh;
  unsigned long loai_thuoctinh=CWBackPixel| CWBorderPixel|CWColormap|CWSaveUnder|CWOverrideRedirect;

  XVisualInfo thongtin_hinhanh;
  XMatchVisualInfo(dp, screen, 32, TrueColor, &thongtin_hinhanh);

  // Mot so thuoc tinh cua cua so 
  thuoc_tinh.background_pixel=0;
  thuoc_tinh.border_pixel = 0;
  thuoc_tinh.save_under=True;
  thuoc_tinh.override_redirect=True;
  thuoc_tinh.colormap=XCreateColormap(dp, DefaultRootWindow(dp), thongtin_hinhanh.visual, AllocNone);

  cua_so = XCreateWindow(dp, WindowGoc, x_phanbu-dolon_vien, y_phanbu-dolon_vien, do_dai+dolon_vien*2, do_rong+dolon_vien*2, 0, thongtin_hinhanh.depth, InputOutput, thongtin_hinhanh.visual, loai_thuoctinh, &thuoc_tinh);

  // Cho phep gui input qua Window
  XserverRegion region = XFixesCreateRegion(dp, NULL, 0);
  XFixesSetWindowShapeRegion(dp, cua_so, ShapeInput, 0, 0, region);
  XFixesDestroyRegion(dp, region);

  XMapWindow(dp, cua_so);

  return cua_so;
}


// Viec ve hinh anh phu thuoc vao display, cua so de ve len va doi tuong de ve 
void ve_hinhanh(Display *dp, int screen, Window cua_so, char **argv, int do_dai, int  do_rong, int dolon_vien){
  // GCForeground cho phep khai bao thuoc tinh ve mau sac
  GC boi_canh;
  unsigned long loai_thuoctinh = GCForeground;
  XGCValues thuoc_tinh;

  XColor mau_den, mau_den_e;
  // TODO: Tang do do cua mau do
  XAllocNamedColor(dp, DefaultColormap(dp, screen), "red", &mau_den, &mau_den_e);
  
  thuoc_tinh.foreground = mau_den.pixel;
  boi_canh = XCreateGC(dp, cua_so, loai_thuoctinh, &thuoc_tinh);
  int trang_thai;

  trang_thai = XFillRectangle(dp, cua_so, boi_canh, 4, 4, do_dai, do_rong);
  char *ki_tu;

  ki_tu = "idk";
  XDrawString(dp, cua_so, boi_canh, 100, 100, ki_tu, strlen(ki_tu));
  XFlush(dp);

  XFreeGC(dp, boi_canh);
}

void ve_hinhchunhat(Display *dp, int screen, Window cua_so, int x_phanbu, int y_phanbu, int do_dai, int do_rong){
  GC boi_canh;
  unsigned long loai_thuoctinh = GCForeground;
  XGCValues thuoc_tinh;

  XColor mau, mau_e;
  XAllocNamedColor(dp, DefaultColormap(dp, screen), "red", &mau, &mau_e);

  thuoc_tinh.foreground = mau.pixel;
  boi_canh = XCreateGC(dp, cua_so, loai_thuoctinh, &thuoc_tinh);

  int trang_thai;
  trang_thai = XFillRectangle(dp, cua_so, boi_canh, x_phanbu, y_phanbu, do_dai, do_rong);
 
  XFlush(dp);

  XFreeGC(dp, boi_canh);
}

