void doc_thongtin(int argc, char **argv);

// Khoi tao mot cua so o tren mot display xac dinh
// Cua so co vi tri la x_phanbu, y_phanbu (goc trai cua ben tren)
Window khoitao_window(Display *dp, int screen, Window WindowGoc, int x_phanbu, int y_phanbu, int do_dai, int  do_rong, int dolon_vien);

void ve_hinhanh(Display *dp, int screen, Window cua_so, char **argv, int do_dai, int  do_rong, int dolon_vien);

void ve_hinhchunhat(Display *dp, int screen, Window cua_so, int x_phanbu, int y_phanbu, int do_dai, int do_rong);
