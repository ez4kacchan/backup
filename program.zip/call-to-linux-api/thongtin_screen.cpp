#include <iostream>
#include <stdio.h>

#include <X11/Xlib.h>

static void Lietke_thongtin(Display *dp){
  printf("Ten cua tap screen: %s\n", DisplayString(dp));
  printf("Nha cung cap cua screen: : %s\n", ServerVendor(dp));
}

static void Lietke_thongtin_screen(Display *dp, int i){
  printf("Kich thuoc: %dx%d\n", XDisplayWidth(dp, i), XDisplayHeight(dp, i));
}

int main(){
  Display *dp = XOpenDisplay(0);
  Lietke_thongtin(dp);
  for (int i = 0; i < ScreenCount(dp); i++) {
    Lietke_thongtin_screen(dp, i);
  }
  return 0;
}

