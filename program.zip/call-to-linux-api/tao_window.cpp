#include <iostream>
#include <stdio.h>

#include <X11/Xlib.h>


int main(){
  Display *dp = XOpenDisplay(0);
  Window window_phu;
  Window root = DefaultRootWindow(dp);

  window_phu = XCreateSimpleWindow(dp, root, 0, 0, 800, 600, 0, 0, 0xffffffff);

  XMapWindow(dp, window_phu);
  
  XEvent *event; 

  XNextEvent(dp, event);
  
  XCloseDisplay(dp);
  return 0;
}
