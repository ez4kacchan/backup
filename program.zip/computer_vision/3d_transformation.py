import numpy as np


def translation_3d(diem, t):
    identity_matrix = np.eye(3)

    last_row = np.array([0, 0, 0, 1])
    translation_matrix = np.hstack((identity_matrix, t.reshape(-1, 1)))
    translation_matrix = np.vstack((translation_matrix, last_row))

    homogeneous_vector = np.array([diem[0], diem[1], diem[2], 1])

    ket_qua = np.dot(translation_matrix, homogeneous_vector)

    return ket_qua[:3]


def orthography(diem):
    transform_matrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
    homogeneous_vector = np.array([diem[0], diem[1], diem[2], 1])

    ket_qua = np.dot(transform_matrix, homogeneous_vector)

    return ket_qua[:2]


def scale_orthography(diem, s):
    transform_matrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1]])

    scale_transform_matrix = s * transform_matrix
    homogeneous_vector = np.array([diem[0], diem[1], diem[2], 1])

    ket_qua = np.dot(scale_transform_matrix, homogeneous_vector)

    return ket_qua[:2]


def thu_nghiem():
    # print(orthography(np.array([1, 2, 3])))
    print(scale_orthography(np.array([1, 2, 3]), 3))


thu_nghiem()
