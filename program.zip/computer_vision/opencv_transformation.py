import cv2


def scale_rot_transform(s, c, a, t):
    rot_matrix = cv2.getRotationMatrix2D(c, a, s)

    # Them thuoc tinh translation
    rot_matrix[0, 2] += t[0]
    rot_matrix[1, 2] += t[1]

    return rot_matrix


def perspective_transform(hinh_anh, nguon, dich, do_dai, do_rong):
    # Do dai va do rong la thuoc tinh cua hinh anh tra ve
    # Nguon la mot mang co 4 gia tri, tuong ung voi 4 vi tri trong hinh anh goc. Con dich la mang 4 gia tri, tuong ung voi 4 vi tri trong hinh anh duoc transform
    # Yeu cau ve gia tri
    trans_matrix = cv2.getPerspectiveTransform(nguon, dich)

    cv2.warpPerspective(hinh_anh, trans_matrix, (do_dai, do_rong))


def thu_nghiem():
    print("Change")


thu_nghiem()
