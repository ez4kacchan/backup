import numpy as np


def translation_2d(diem, t):
    identity_matrix = np.eye(2)

    last_row = np.array([0, 0, 1])
    translation_matrix = np.hstack((identity_matrix, t.reshape(-1, 1)))
    translation_matrix = np.vstack((translation_matrix, last_row))
    # translation_matrix = np.array([[1, 0, tx], [0, 1, ty], [0, 0, 1]])

    homogeneous_vector = np.array([diem[0], diem[1], 1])

    ket_qua = np.dot(translation_matrix, homogeneous_vector)

    return ket_qua[:2]


def rotation_translation_2d(diem, theta, t):
    rotation_matrix = np.array(
        [[np.cos(theta), np.sin(theta)], [-np.sin(theta), np.cos(theta)]]
    )

    ket_qua = rotation_matrix.shape
    matrix_chinh = np.hstack((rotation_matrix, t.reshape(-1, 1)))

    homogeneous_vector = np.array([diem[0], diem[1], 1])

    ket_qua = np.dot(matrix_chinh, homogeneous_vector)

    return ket_qua


def scale_rotation_2d(diem, theta, s, t):
    rot_matrix = np.array(
        [[np.cos(theta), np.sin(theta)], [-np.sin(theta), np.cos(theta)]]
    )

    scale_rotmatrix = s * rot_matrix
    matrix_chinh = np.hstack((scale_rotmatrix, t.reshape(-1, 1)))

    homogeneous_vector = np.array([diem[0], diem[1], 1])

    ket_qua = np.dot(matrix_chinh, homogeneous_vector)

    return ket_qua


def thu_nghiem():
    # print(translation_2d(np.array([2, 3]), np.array([3, 4])))
    # print(rotation_translation_2d(np.array([2, 3]), np.pi / 6, np.array([3, 4])))
    # print(scale_rotation_2d(np.array([2, 3]), np.pi / 6, 3, np.array([3, 4])))
    print(translation_3d(np.array([1, 2, 3]), np.array([3, 4, 5])))


thu_nghiem()
