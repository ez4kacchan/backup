#include <stdio.h>

void xuly_hoatdong(int &kiem_tra){
  if (kiem_tra != true){
    kiem_tra = true;
    return 0;
  }
  else {
    kiem_tra = false;
    return 1;
  }
}

int main(){
  bool check = true;
  while (true){
    int tra_ve = xuly_hoatdong(&check);
    printf("%d", tra_ve);
  }

  return 0;
}
