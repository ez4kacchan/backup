void doc_thongtin(int argc, char **argv);

static bool isExtensionSupported(const char *, const char *);
