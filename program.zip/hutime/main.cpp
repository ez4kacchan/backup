// Library de tuong tac voi X Serverx
#include <X11/Xlib.h>
#include <X11/extensions/shape.h>
#include <X11/extensions/Xfixes.h>

// Libray OpenGL de giup de dang cho viec ve tren cua so
#include <GL/gl.h>
#include <GL/glx.h>

#include <string.h>
#include <stdio.h>
#include <iostream>
#include <time.h>

#define DODAI_CUASO 800
#define DORONG_CUASO 600
#define DODAI_MANHINH 1920
#define DORONG_MANHINH 1080

typedef struct {
  double tren_trai, duoi_phai;
} hinh_chunhat;

void doc_thongtin(int argc, char **argv){
  printf("argc: %d \n", argc);
  for (int i=1; i<argc; i++){
    if (!(strcmp(argv[i], "-c"))){
      if (i+1<argc){
        printf("arg cho color: %s \n", argv[i+1]);
      }
    }
  }
}


static bool isExtensionSupported(const char *extList, const char *extension) {
	return strstr(extList, extension) != 0;
}

float x_thanh_glx(int dodai, int dodai_thucte){
  return (2.0f * dodai / dodai_thucte) - 1.0f;
}

float y_thanh_gly(int dorong, int dorong_thucte){
  return 1.0f - (2.0f * dorong / dorong_thucte);
}

void xuly_hoatdong(bool *kiem_tra, time_t *t){
  double time_taken;
  if (*kiem_tra != true){
    *kiem_tra = true;
    *t = time(NULL) - *t;
    std::cout << *t << "\n";
  }
  else {
    *kiem_tra = false;
    *t = time(NULL);
  }
}

// void Render(){
//   glClear(GL_COLOR_BUFFER_BIT);
//   glBegin(GL_QUADS);
//       glColor3f(1.0f, 0.0f, 0.0f);
//       glVertex2f(-0.25f, -0.5f);
//       glVertex2f( 0.25f, -0.5f);
//       glVertex2f( 0.25f, -0.75f);
//       glVertex2f(-0.25f, -0.75f);
//   glEnd();
//
//   glXSwapBuffers(display, cuaso_chinh);
// }

int main(int argc, char **argv){
  Display *display;
  display = XOpenDisplay(NULL);
  int screen = DefaultScreen(display);

  Window cuaso_chinh;

  // Khoi tao boi canh cua X11 
  XGCValues thuoc_tinh;

	// Tao cua so
  XVisualInfo *thuoctinh_hoatanh;
	GLint        visual_attributes[5] = { GLX_RGBA, GLX_DEPTH_SIZE, 24, None };

	thuoctinh_hoatanh = glXChooseVisual(display,screen, visual_attributes);

  // Thuoc tinh cua cua so 
	XSetWindowAttributes thuoctinh_cuaso;
	thuoctinh_cuaso.border_pixel = BlackPixel(display, screen);
	thuoctinh_cuaso.background_pixel = 0;
	thuoctinh_cuaso.override_redirect = True;
	thuoctinh_cuaso.colormap = XCreateColormap(display, RootWindow(display, screen), thuoctinh_hoatanh->visual, AllocNone);
	thuoctinh_cuaso.event_mask = ButtonPressMask|KeyPressMask|ExposureMask;
	cuaso_chinh = XCreateWindow(display, RootWindow(display, screen), 0, 0, DODAI_CUASO, DORONG_CUASO, 0, thuoctinh_hoatanh->depth, InputOutput, thuoctinh_hoatanh->visual, CWBackPixel | CWColormap | CWBorderPixel | CWEventMask, &thuoctinh_cuaso);
  
  // Hien thi cua so
  XClearWindow(display, cuaso_chinh);
	XMapRaised(display, cuaso_chinh);

  // Xu ly thao tac thoat cua so
	Atom atomWmDeleteWindow = XInternAtom(display, "WM_DELETE_WINDOW", False);
	XSetWMProtocols(display, cuaso_chinh, &atomWmDeleteWindow, 1);

  GLXContext boicanh_gl;
  boicanh_gl = glXCreateContext(display, thuoctinh_hoatanh,NULL,GL_TRUE);

	if (!glXIsDirect (display, boicanh_gl)) {
		std::cout << "Indirect GLX rendering context obtained\n";
	
	else {
		std::cout << "Direct GLX rendering context obtained\n";
	}
  
  glXMakeCurrent(display, cuaso_chinh, boicanh_gl);
  
  XWindowAttributes attrib;
  XGetWindowAttributes(display, cuaso_chinh, &attrib);

  int dodai_thucte = attrib.width;
  int dorong_thucte = attrib.height;


  XEvent hoat_dong;
  // Xu ly cac hoat dong o cua so
  char text[10];
  KeySym nut_an;
  int i;
  float gl_x; 
  float gl_y; 
  int hoan_thanh = 0;
  bool check = true;
  time_t t;
  double time_taken;

	while (hoan_thanh == 0) {
    XNextEvent(display, &hoat_dong);

    if (&hoat_dong == NULL){
      hoan_thanh = 1;
    }

    switch(hoat_dong.type){
      case Expose: 
        if (hoat_dong.xexpose.count == 0){
          glEnable(GL_BLEND);
          glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
          glClearColor(0.0f, 0.0f, 0.0f, 0.0f); 
          glClear(GL_COLOR_BUFFER_BIT);
          glBegin(GL_QUADS);
            glColor3f(1.0f, 0.0f, 0.0f); // Red color
            glVertex2f(-0.5f, -0.5f);
            glVertex2f( 0.5f, -0.5f);
            glVertex2f( 0.5f,  0.5f);
            glVertex2f(-0.5f,  0.5f);
          glEnd();
        }
        glXSwapBuffers(display, cuaso_chinh);
        break;
      case ButtonPress:
        // gl_x = (2.0f * hoat_dong.xbutton.x / dodai_thucte) - 1.0f;
        // gl_y = 1.0f - (2.0f * hoat_dong.xbutton.y / dorong_thucte);
      
        xuly_hoatdong(&check, &t);
        
        break;
      case KeyPress:
        // Key Input
        i = XLookupString(&hoat_dong.xkey, text, 10, &nut_an, 0);
        if(i==1 && text[0]=='q') hoan_thanh = 1;
        break;
      case DestroyNotify:
        break;
    }
	}

  // Don dep OpenGL
	glXDestroyContext(display, boicanh_gl);
  
  // Don dep X11
  // XFreeGC(display, boi_canh);
  XDestroyWindow(display, cuaso_chinh);
  XCloseDisplay(display);

  return 0;
}

