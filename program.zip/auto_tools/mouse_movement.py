import evdev
from evdev import InputDevice, categorize, UInput
from evdev import ecodes as e
import os
import time


class KeyEvent:
    def __init__(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value

    def update(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value


if __name__ == "__main__":
    devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
    for device in devices:
        if device.name == "AT Translated Set 2 keyboard":
            print("Loaded")
            banphim = device
        if device.name == "SYNA32B8:00 06CB:CE7D Mouse":
            chuot = device
    ui = UInput.from_device(chuot, banphim, name="thietbi-banphim-chuot")

    for event in banphim.read_loop():
        if event.type == e.EV_KEY and event.code == e.KEY_G:
            print("ah yes")
            output_key = 0
            ui.write(1, 272, event.value)
            ui.syn()
            # ui.write(e.EV_REL, e.REL_X, -100)
            # ui.syn()

        if event.code == e.KEY_DELETE:
            os._exit(0)
