import pyautogui
import time
import signal
import sys


def auto_scroll(seconds, scroll_amount=2):
    """
    Automatically scrolls the mouse down after a specified number of seconds.

    :param seconds: Number of seconds to wait before scrolling.
    :param scroll_amount: Amount to scroll down. Default is 100.
    """
    time.sleep(seconds)
    pyautogui.scroll(-scroll_amount)  # Negative value for scrolling down


def signal_handler(sig, frame):
    print("You pressed Ctrl+C! Exiting gracefully.")
    sys.exit(0)


signal.signal(signal.SIGINT, signal_handler)

if __name__ == "__main__":
    try:
        print(sys.exec_prefix)
        while True:
            auto_scroll(15)  # Change 5 to the number of seconds you want to wait
    except KeyboardInterrupt:
        print("You pressed Ctrl+C! Exiting gracefully.")
