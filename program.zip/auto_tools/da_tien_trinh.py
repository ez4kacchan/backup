import asyncio
import time


async def xuat_sau(thoigian, noidung):
    await asyncio.sleep(thoigian)
    print(noidung)


async def main():
    asyncio.create_task(xuat_sau(1, "nhao"))
    print(f"Thoi diem truoc : {time.time()}")
    # await xuat_sau(1, "nhao")
    # await xuat_sau(2, "zo")
    print(f"Thoi diem hien tai: {time.time()}")


if __name__ == "__main__":
    asyncio.run(main(), debug=True)
