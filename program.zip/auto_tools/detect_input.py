import evdev
from evdev import InputDevice, categorize, UInput
from evdev import ecodes as e
import os


class KeyEvent:
    def __init__(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value

    def update(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value


if __name__ == "__main__":
    thietbis = (evdev.InputDevice(path) for path in evdev.list_devices())
    for thietbi in thietbis:
        if thietbi.name == "AT Translated Set 2 keyboard":
            dev = thietbi

    ui = UInput()
    last_time = 0
    current_gime = 0
    time_gap = 0
    dev.grab()

    for event in dev.read_loop():
        print(categorize(event))

        if event.code == e.KEY_DELETE:
            dev.ungrab()
            os._exit(0)
