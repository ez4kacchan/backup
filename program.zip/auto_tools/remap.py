import threading
import evdev
from concurrent.futures import ThreadPoolExecutor
from evdev import UInput
from evdev import ecodes as e
import os
from keymap import *
import time


def thaydoi_nut(map):
    pass


if __name__ == "__main__":
    devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
    for device in devices:
        if device.name == "AT Translated Set 2 keyboard":
            print("Loaded")
            ban_phim = device
        if device.name == "SYNA32B8:00 06CB:CE7D Mouse":
            chuot = device
        if device.name == "SYNA32B8:00 06CB:CE7D Touchpad":
            chuot2 = device

    ui = UInput.from_device(ban_phim, chuot, name="thietbi-banphim-chuot-2")
    ban_phim.grab()
    chuot2.grab()

    thaydoi_nut(default_map)

    khoa = threading.Lock()
    toggle = True
    for event in ban_phim.read_loop():
        if event.type == e.EV_KEY and event.code in default_map:
            output_key = default_map[event.code]
            ui.write(e.EV_KEY, output_key, event.value)
            ui.syn()

        # if event.type == e.EV_KEY and event.code == e.KEY_5KP6 and event.value == 1:
        #     with khoa:
        #         with ThreadPoolExecutor() as thucthi:

        if event.type == e.EV_KEY and event.code == e.KEY_CAPSLOCK and event.value == 1:
            if toggle:
                chuot2.ungrab()
                toggle = not toggle
            else:
                chuot2.grab()
                toggle = not toggle

        # if event.type == e.EV_KEY and event.code == e.KEY_CAPSLOCK and event.value == 0:
        #     chuot2.grab()

        if event.code == e.KEY_DELETE:
            ban_phim.ungrab()
            os._exit(0)
