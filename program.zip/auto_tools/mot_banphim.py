import threading
import evdev
from concurrent.futures import ThreadPoolExecutor
from evdev import UInput
from evdev import ecodes as e
import os
from keymap import *
import time


def thaydoi_nut(map):
    map[e.KEY_CAPSLOCK] = e.KEY_RIGHTCTRL


def khoanguoi(ui):
    # Thao tac 1
    ui.write(e.EV_KEY, 273, 1)
    ui.syn()
    time.sleep(0.05)
    ui.write(e.EV_KEY, 273, 0)
    ui.syn()
    time.sleep(0.05)
    ui.write(e.EV_KEY, e.KEY_LEFTSHIFT, 1)
    ui.syn()
    time.sleep(0.05)
    ui.write(e.EV_KEY, e.KEY_LEFTSHIFT, 0)
    ui.syn()
    time.sleep(0.09)
    return 1


def thaotac_xoaynguoi(ui, dolon):
    # Thao tac 2
    print(thaotac1.result())
    ui.write(e.EV_REL, e.REL_X, dolon)
    ui.syn()
    time.sleep(0.05)
    return dolon


def thaotac_nhay(ui):
    # Thao tac 3
    print(thaotac2.result())
    ui.write(e.EV_KEY, e.KEY_SPACE, 1)
    ui.syn()
    time.sleep(0.05)
    ui.write(e.EV_REL, e.REL_X, -thaotac2.result())
    ui.syn()
    time.sleep(0.05)
    ui.write(e.EV_KEY, e.KEY_SPACE, 0)
    ui.syn()
    time.sleep(0.05)
    return thaotac2.result()


def thaotac_danh(ui, do_tre, ngua_truoc):
    # Thao tac 4
    print(thaotac3.result())
    time.sleep(do_tre)
    if ngua_truoc == True:
        ui.write(e.EV_KEY, e.KEY_W, 1)
        ui.syn()
        time.sleep(0.05)
        ui.write(e.EV_KEY, e.KEY_W, 1)
        ui.syn()
        time.sleep(0.05)
    ui.write(e.EV_KEY, 272, 1)
    ui.syn()
    time.sleep(0.05)
    ui.write(e.EV_KEY, 272, 0)
    ui.syn()
    time.sleep(0.05)
    if ngua_truoc == True:
        ui.write(e.EV_KEY, e.KEY_W, 0)
        ui.syn()
        time.sleep(0.02)


if __name__ == "__main__":
    devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
    for device in devices:
        if device.name == "AT Translated Set 2 keyboard":
            print("Loaded")
            dev = device
    ui = UInput.from_device(dev, name="thietbi-banphim-chuot-2")
    dev.grab()

    thaydoi_nut(default_map)

    khoa = threading.Lock()
    for event in dev.read_loop():
        if event.type == e.EV_KEY and event.code in default_map:
            output_key = default_map[event.code]
            ui.write(e.EV_KEY, output_key, event.value)
            ui.syn()

        if event.type == e.EV_KEY and event.code == e.KEY_KP5 and event.value == 1:
            with khoa:
                with ThreadPoolExecutor() as thucthi:
                    thaotac1 = thucthi.submit(khoanguoi, ui)
                    thaotac2 = thucthi.submit(thaotac_xoaynguoi, ui, -500)
                    thaotac3 = thucthi.submit(thaotac_nhay, ui)
                    thaotac4 = thucthi.submit(thaotac_danh, ui, 0.18, True)

        if event.type == e.EV_KEY and event.code == e.KEY_KP6 and event.value == 1:
            with khoa:
                with ThreadPoolExecutor() as thucthi:
                    thaotac1 = thucthi.submit(khoanguoi, ui)
                    thaotac2 = thucthi.submit(thaotac_xoaynguoi, ui, -1190)
                    thaotac3 = thucthi.submit(thaotac_nhay, ui)
                    thaotac4 = thucthi.submit(thaotac_danh, ui, 0.18, True)

        if event.code == e.KEY_DELETE:
            dev.ungrab()
            os._exit(0)
