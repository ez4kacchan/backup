import evdev
from evdev import InputDevice, categorize, UInput
from evdev import ecodes as e
import os
import time


default_map = {
    # Top row
    e.KEY_GRAVE: e.KEY_GRAVE,
    e.KEY_1: e.KEY_1,
    e.KEY_2: e.KEY_2,
    e.KEY_3: e.KEY_3,
    e.KEY_4: e.KEY_4,
    e.KEY_5: e.KEY_5,
    e.KEY_6: e.KEY_6,
    e.KEY_7: e.KEY_7,
    e.KEY_8: e.KEY_8,
    e.KEY_9: e.KEY_9,
    e.KEY_0: e.KEY_0,
    e.KEY_MINUS: e.KEY_MINUS,
    e.KEY_EQUAL: e.KEY_EQUAL,
    # Second row
    e.KEY_TAB: e.KEY_TAB,
    e.KEY_Q: e.KEY_Q,
    e.KEY_W: e.KEY_W,
    e.KEY_E: e.KEY_E,
    e.KEY_R: e.KEY_R,
    e.KEY_T: e.KEY_T,
    e.KEY_Y: e.KEY_Y,
    e.KEY_U: e.KEY_U,
    e.KEY_I: e.KEY_I,
    e.KEY_O: e.KEY_O,
    e.KEY_P: e.KEY_P,
    e.KEY_LEFTBRACE: e.KEY_LEFTBRACE,
    e.KEY_RIGHTBRACE: e.KEY_RIGHTBRACE,
    e.KEY_BACKSLASH: e.KEY_BACKSLASH,
    # Third row
    e.KEY_A: e.KEY_A,
    e.KEY_S: e.KEY_S,
    e.KEY_D: e.KEY_D,
    e.KEY_F: e.KEY_F,
    e.KEY_G: e.KEY_G,
    e.KEY_H: e.KEY_H,
    e.KEY_J: e.KEY_J,
    e.KEY_K: e.KEY_K,
    e.KEY_L: e.KEY_L,
    e.KEY_SEMICOLON: e.KEY_SEMICOLON,
    e.KEY_APOSTROPHE: e.KEY_APOSTROPHE,
    # Fourth row
    e.KEY_Z: e.KEY_Z,
    e.KEY_X: e.KEY_X,
    e.KEY_C: e.KEY_C,
    e.KEY_V: e.KEY_V,
    e.KEY_B: e.KEY_B,
    e.KEY_N: e.KEY_N,
    e.KEY_M: e.KEY_M,
    e.KEY_COMMA: e.KEY_COMMA,
    e.KEY_DOT: e.KEY_DOT,
    e.KEY_SLASH: e.KEY_SLASH,
    # Special Key
    e.KEY_LEFTSHIFT: e.KEY_LEFTSHIFT,
    e.KEY_RIGHTSHIFT: e.KEY_RIGHTSHIFT,
    e.KEY_LEFTALT: e.KEY_LEFTALT,
    e.KEY_RIGHTALT: e.KEY_LEFTALT,
    e.KEY_RIGHTCTRL: e.KEY_RIGHTCTRL,
    e.KEY_LEFTCTRL: e.KEY_LEFTCTRL,
    e.KEY_SPACE: e.KEY_ESC,
    e.KEY_BACKSPACE: e.KEY_BACKSPACE,
    e.KEY_ENTER: e.KEY_ENTER,
    e.KEY_UP: e.KEY_UP,
    e.KEY_LEFT: e.KEY_LEFT,
    e.KEY_RIGHT: e.KEY_RIGHT,
    e.KEY_DOWN: e.KEY_DOWN,
    e.KEY_SYSRQ: e.KEY_SYSRQ,
}


class KeyEvent:
    def __init__(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value

    def update(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value


if __name__ == "__main__":
    devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
    for device in devices:
        if device.name == "AT Translated Set 2 keyboard":
            print("Loaded")
            dev = device
    ui = UInput()
    dev.grab()
    tep_luutru_nut = []

    for event in dev.read_loop():
        if event.type == e.EV_KEY:
            tep_luutru_nut.append(event)
            thoidiem_baygio = time.time()
            # print("Event cuoi: ", tep_luutru_nut[-1])
            if len(tep_luutru_nut) > 1:
                if tep_luutru_nut[-2].code == 30 and tep_luutru_nut[-1].code == 57:
                    print("Co tin hieu muon nhay")
                    ui.write(e.EV_KEY, 30, 0)
                    ui.syn()
                    time.sleep(0.06)
                    ui.write(e.EV_KEY, 57, 1)
                    ui.syn()
                    ui.write(e.EV_KEY, 57, 0)
                # print("event ap cuoi: ", tep_luutru_nut[-2])

        if event.type == e.EV_KEY and event.code in default_map:
            output_key = default_map[event.code]
            ui.write(e.EV_KEY, output_key, event.value)
            ui.syn()

        if event.code == e.KEY_DELETE:
            dev.ungrab()
            os._exit(0)
