import evdev
from evdev import InputDevice, categorize, UInput
from evdev import ecodes as e
import os
import time
import asyncio

tinhieu_macdinh = {
    # Top row
    e.KEY_GRAVE: e.KEY_GRAVE,
    e.KEY_1: e.KEY_1,
    e.KEY_2: e.KEY_2,
    e.KEY_3: e.KEY_3,
    e.KEY_4: e.KEY_4,
    e.KEY_5: e.KEY_5,
    e.KEY_6: e.KEY_6,
    e.KEY_7: e.KEY_7,
    e.KEY_8: e.KEY_8,
    e.KEY_9: e.KEY_9,
    e.KEY_0: e.KEY_0,
    e.KEY_MINUS: e.KEY_MINUS,
    e.KEY_EQUAL: e.KEY_EQUAL,
    # Second row
    e.KEY_TAB: e.KEY_TAB,
    e.KEY_Q: e.KEY_Q,
    e.KEY_W: e.KEY_W,
    e.KEY_E: e.KEY_E,
    e.KEY_R: e.KEY_R,
    e.KEY_T: e.KEY_T,
    e.KEY_Y: e.KEY_Y,
    e.KEY_U: e.KEY_U,
    e.KEY_I: e.KEY_I,
    e.KEY_O: e.KEY_O,
    e.KEY_P: e.KEY_P,
    e.KEY_LEFTBRACE: e.KEY_LEFTBRACE,
    e.KEY_RIGHTBRACE: e.KEY_RIGHTBRACE,
    e.KEY_BACKSLASH: e.KEY_BACKSLASH,
    # Third row
    e.KEY_A: e.KEY_A,
    e.KEY_S: e.KEY_S,
    e.KEY_D: e.KEY_D,
    e.KEY_F: e.KEY_F,
    e.KEY_G: e.KEY_G,
    e.KEY_H: e.KEY_H,
    e.KEY_J: e.KEY_J,
    e.KEY_K: e.KEY_K,
    e.KEY_L: e.KEY_L,
    e.KEY_SEMICOLON: e.KEY_SEMICOLON,
    e.KEY_APOSTROPHE: e.KEY_APOSTROPHE,
    # Fourth row
    e.KEY_Z: e.KEY_Z,
    e.KEY_X: e.KEY_X,
    e.KEY_C: e.KEY_C,
    e.KEY_V: e.KEY_V,
    e.KEY_B: e.KEY_B,
    e.KEY_N: e.KEY_N,
    e.KEY_M: e.KEY_M,
    e.KEY_COMMA: e.KEY_COMMA,
    e.KEY_DOT: e.KEY_DOT,
    e.KEY_SLASH: e.KEY_SLASH,
    # Special Key
    e.KEY_LEFTSHIFT: e.KEY_LEFTSHIFT,
    e.KEY_RIGHTSHIFT: e.KEY_RIGHTSHIFT,
    e.KEY_LEFTALT: e.KEY_LEFTALT,
    e.KEY_RIGHTALT: e.KEY_LEFTALT,
    e.KEY_RIGHTCTRL: e.KEY_RIGHTCTRL,
    e.KEY_LEFTCTRL: e.KEY_LEFTCTRL,
    e.KEY_SPACE: e.KEY_SPACE,
    e.KEY_ENTER: e.KEY_ENTER,
    e.KEY_UP: e.KEY_UP,
    e.KEY_LEFT: e.KEY_LEFT,
    e.KEY_RIGHT: e.KEY_RIGHT,
    e.KEY_DOWN: e.KEY_DOWN,
    e.KEY_MUHENKAN: e.KEY_BACKSPACE,
}


class KeyEvent:
    def __init__(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value

    def update(self, type, code, value):
        self.code = code
        self.type = type
        self.value = value


async def doc_dauvao(thietbi):
    async for event in thietbi.async_read_loop():
        if thietbi.name == "SYNA32B8:00 06CB:CE7D Touchpad":
            print(categorize(event))
            print(f"------------")
            if event.type == e.EV_KEY and event.code == 
            if event.code == e.KEY_DELETE:
                os._exit(0)


if __name__ == "__main__":
    thietbis = (evdev.InputDevice(path) for path in evdev.list_devices())
    for thietbi in thietbis:
        if thietbi.name == "SYNA32B8:00 06CB:CE7D Touchpad":
            chuot = thietbi
        if thietbi.name == "PFU Limited HHKB-Hybrid":
            banphim = thietbi

    for thietbi in chuot, banphim:
        asyncio.ensure_future(doc_dauvao(thietbi))

    vonglap = asyncio.get_event_loop()
    vonglap.run_forever()
    #
    # ui = UInput.from_device(chuot, banphim, name="thietbi-banphim-chuot")
    # chuot.grab()
    #
    # for event in chuot.read_loop():
    #     print(categorize(event))
    #
    #     if event.code == e.KEY_DELETE:
    #         chuot.ungrab()
    #         os._exit(0)
