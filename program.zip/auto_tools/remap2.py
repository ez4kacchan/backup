import evdev
from evdev import UInput
from evdev import ecodes as e
import os
from keymap import *


def thaydoi_nut(map):
    map[e.KEY_MUHENKAN] = e.KEY_BACKSPACE
    del map[e.KEY_H], map[e.KEY_J], map[e.KEY_K]


if __name__ == "__main__":
    devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
    for device in devices:
        if device.name == "PFU Limited HHKB-Hybrid":
            print("Loaded")
            banphim = device
        if device.name == "SYNA32B8:00 06CB:CE7D Mouse":
            chuot = device
        if device.name == "SYNA32B8:00 06CB:CE7D Touchpad":
            chuot2 = device

    ui = UInput.from_device(chuot, banphim, name="PFU Limited HHKB-Hybrid")
    banphim.grab()
    chuot2.grab()

    thaydoi_nut(default_map)

    for event in banphim.read_loop():
        if event.type == e.EV_KEY and event.code in default_map:
            output_key = default_map[event.code]
            ui.write(e.EV_KEY, output_key, event.value)
            ui.syn()

        if event.type == e.EV_KEY and event.code == e.KEY_H and event.value == 1:
            chuot2.ungrab()

        if event.type == e.EV_KEY and event.code == e.KEY_H and event.value == 0:
            chuot2.grab()

        if event.type == e.EV_KEY and event.code == e.KEY_J:
            ui.write(1, 272, event.value)
            ui.syn()

        if event.type == e.EV_KEY and event.code == e.KEY_M:
            ui.write(1, 273, event.value)
            ui.syn()

        if event.code == e.KEY_DELETE:
            banphim.ungrab()
            os._exit(0)
