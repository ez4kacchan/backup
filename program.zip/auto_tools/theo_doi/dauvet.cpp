#include <sys/ptrace.h>
#include <iostream>

int main() {
  std::cout << "idk";
  return 0;
}

