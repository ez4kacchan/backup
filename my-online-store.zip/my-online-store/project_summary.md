## Slogan
- Our mission is to minimize the cost of premium accounts and services. 
- No more chasing your friends for refunds, or hesitating to take out a Netflix or Spotify subscription.

## Task
1. Storefront:
- [ ] Homepage 
- [ ] Policy, About us, Contact



