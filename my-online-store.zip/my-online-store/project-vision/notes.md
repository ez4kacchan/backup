## Framework
1. Shopify: 
  - Basic plan: 1$ first month, later 19$ + 2% fee for payment
  - Pros:
    + Less time for development
    + Easy for development
  - Cons:
    + Have to upgrade if the store scale??

2. Wordpress: 
  - Very cheap share hosting provider. Spending money on buying plugins.
  - Pros:
    + Look like it is cheap
    + Most used fw, having vietnamese community
  - Cons:
    + Speed problem
    + Sometimes require large amount of time to fix problem
    + Need to spend money on buying plugins

## Questions
- Using old fw to it's maximum capacity or using moderm fw with cutting edge tech?

## Requirement
- Dev friendly, Low cost in short term and long term. 
- Successful stories with fw
