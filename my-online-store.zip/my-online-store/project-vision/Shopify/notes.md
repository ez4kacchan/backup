## Strategy
- Make use of 1$ for first month
- Build storefront before buying sub
- Find payment provider for vietnamese customer

## Event
